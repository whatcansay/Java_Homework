package sixthHomework;
import java.util.*;
public class code9_6 {

	public static void main(String[] args) {
		int[] arr = new int[100000];
        Random rd = new Random();
        for (int i = 0 ; i < arr.length ; i++){
            arr[i] = rd.nextInt(100000);
        }
        StopWatch sw = new StopWatch();
        Arrays.sort(arr);
        sw.stop();
        System.out.println("ִ����" + sw.getElaspsedTime() + "����");
	}
	
}
class StopWatch {
    private long startTime, endTime;

    public StopWatch(){
        startTime = System.currentTimeMillis();
    }

    public void stop(){
        this.endTime = System.currentTimeMillis();
    }

    public long getElaspsedTime(){
        return this.endTime - this.startTime;
    }
}

