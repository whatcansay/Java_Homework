package sixthHomework;
import java.util.*;
public class code9_3 {

	public static void main(String[] args) {
		Date date=new Date();
		for(long i=10000;i<=1e10;i*=10) {
			date.setTime(i);
			System.out.println(date.toString());
		}
	}


}
