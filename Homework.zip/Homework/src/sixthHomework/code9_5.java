package sixthHomework;
import java.util.*;
public class code9_5 {
	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
        GregorianCalendar g=new GregorianCalendar();
        g.setTimeInMillis(in.nextLong());
        System.out.println(g.get(Calendar.YEAR)+"-"+g.get(Calendar.MONTH)+"-"+g.get(Calendar.DAY_OF_MONTH));
        in.close();
	}

}
