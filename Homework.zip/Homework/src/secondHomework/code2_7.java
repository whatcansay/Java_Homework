package secondHomework;

public class code2_7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long tm=System.currentTimeMillis();
		long ts=tm/1000;
		long cs=ts%60;
		long tmd=ts/60;
		long cnm=tmd%60;
		long tnm=tmd/60;
		long ch=tnm%23;
		System.out.println("Current time is "+ch+":"+cnm+":"+cs+" GMT");
	}

}
