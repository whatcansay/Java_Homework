package secondHomework;

public class code2_1 {
	public static void main(String[] args) {
		double r=20;
		double a=r*r*3.14159;
		System.out.print("The area for the circle of radius "+r+" is "+a);
	}
}
