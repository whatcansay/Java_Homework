package secondHomework;
import  java.util.*;
public class code2_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input=new Scanner(System.in);
		System.out.print("Enter a number for radius: ");
		int s=input.nextInt();
		int m=s/60;
		int r=s%60;
		System.out.println(s+"seconds is "+m+" minutes and "+r+" seconds");
	}

}
