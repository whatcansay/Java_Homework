package secondHomework;
import java.util.*;
public class code2_6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input=new Scanner(System.in);
		
		System.out.print("Enter a degree for radius: ");
		double n=input.nextDouble();
		double c=(5.0/9)*(n-32);
		System.out.println("fahrenheit "+n+" is "+c+"in celsius");

	}

}
