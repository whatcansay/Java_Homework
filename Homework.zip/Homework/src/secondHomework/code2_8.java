package secondHomework;
import java.util.*;
public class code2_8 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input=new Scanner(System.in);
		double p=input.nextDouble();
		double t=p*0.06;
		System.out.println("Sales tax is $"+(int)(t*100)/100.0);
	}
}
