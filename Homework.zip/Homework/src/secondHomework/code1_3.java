package secondHomework;

public class code1_3 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("(10.5 + 2 * 3) / (45 - 3.5) = ");
        System.out.println((10.5 + 2 * 3) / (45 - 3.5));
	}
}
