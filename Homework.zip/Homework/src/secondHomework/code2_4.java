package secondHomework;
import java.util.*;
public class code2_4 {

	public static void main(String[] args) {
	// TODO Auto-generated method stub

		Scanner input=new Scanner(System.in);
		
		System.out.print("Enter a number for radius: ");
		double n1=input.nextDouble();
		double a=n1*n1*3.14159;
		
		System.out.println(n1+" is "+a);
		

	}

}
