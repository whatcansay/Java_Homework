package secondHomework;
import java.util.*;
public class code2_3 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input=new Scanner(System.in);
		
		System.out.print("Enter three number for radius: ");
		double n1=input.nextDouble();
		double n2=input.nextDouble();
		double n3=input.nextDouble();
		double av=n1+n2+n3;
		av/=3.0;
		System.out.println(n1+" "+n2+" "+n3+"="+av);
	}

}
