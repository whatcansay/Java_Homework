package fifthHomework;
import java.util.*;
public class code9_1 {
	public static void main(String[] args) {
		//ccasdasd
		SimpleCircle circle1=new SimpleCircle();
		System.out.println("r"+circle1.radius+"is"+circle1.getArea());
		SimpleCircle circle2=new SimpleCircle(25);
		System.out.println("r"+circle2.radius+"is"+circle2.getArea());
		SimpleCircle circle3=new SimpleCircle(125);
		System.out.println("r"+circle3.radius+"is"+circle3.getArea());
		circle2.radius=100;
		System.out.println("r"+circle2.radius+"is"+circle2.getArea());
		
	}
	
}
class SimpleCircle{
	double radius;
	SimpleCircle(){
		radius=1;
	}
	SimpleCircle(double newRadius){
		radius=newRadius;
	}
	double getArea() {
		return radius*radius*Math.PI;
	}
	double getPerimeter() {
		return 2*radius*Math.PI;
	}
	void setRadius(double sda) {
		radius=sda;
	}
}


