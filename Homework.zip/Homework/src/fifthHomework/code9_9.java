package fifthHomework;
import java.util.Scanner;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
public class code9_9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		code9_8Circle myCircle=new code9_8Circle(5.0);
		System.out.println("The area of the circle of radius "
		+myCircle.getRadius()+" is "+myCircle.getArea());
		myCircle.setRadius(myCircle.getRadius()*1.1);
		System.out.println("The area of the circle of radius "
		+myCircle.getRadius()+" is "+myCircle.getArea());
		
	}


}
