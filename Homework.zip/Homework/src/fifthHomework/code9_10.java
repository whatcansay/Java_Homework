package fifthHomework;
import fifthHomework.Point2D;
import java.util.*;
public class code9_10 {

	public static void main(String[] args) {
		code9_8Circle myCircle=new code9_8Circle(1);
		int n=5;
		System.out.println("\n"+"Radius is "+myCircle.getRadius());
		System.out.println("n is "+n);
	}
	public static void printAreas(
			code9_8Circle c,int times) {
		System.out.println("Radius \t\tArea");
		while(times>=1) {
			System.out.println(c.getRadius()+"\t\t"+c.getArea());
			c.setRadius(c.getRadius()+1);
			times--;
		}
	}

}
