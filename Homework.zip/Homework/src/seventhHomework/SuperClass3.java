package seventhHomework;

public class SuperClass3 {
	 public void showValue(int arg) {
	      System.out.println("SUPERCLASS: " + "The int argument was " + arg);
	   }
	   public void showValue(String arg) {
	      System.out.println("SUPERCLASS: " + "The String argument was " + arg);
	   }
}
