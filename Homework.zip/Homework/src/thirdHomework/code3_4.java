package thirdHomework;
import java.util.*;
public class code3_4 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Scanner input=new Scanner(System.in);
		Random r=new Random(3);
		int ran1=r.nextInt(13);
		if(ran1==1) {
			System.out.println("January");
		}
		else if(ran1==2) {
			System.out.println("February");
		}
		else if(ran1==3) {
			System.out.println("March");
		}
		else if(ran1==4) {
			System.out.println("April");
		}
		else if(ran1==5) {
			System.out.println("May");
		}
		else if(ran1==6) {
			System.out.println("June");
		}
		else if(ran1==7) {
			System.out.println("July");
		}
		else if(ran1==8) {
			System.out.println("August");
		}
		else if(ran1==9) {
			System.out.println("September");
		}
		else if(ran1==10) {
			System.out.println("October");
		}
		else if(ran1==11) {
			System.out.println("Novenber");
		}
		else if(ran1==12) {
			System.out.println("December");
		}
	}
}
