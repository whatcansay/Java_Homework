package thirdHomework;
import java.util.*;
public class code5_26 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("����");
		Scanner input=new Scanner(System.in);
//		int n=input.nextInt();
		int n;
		n=10000;
		double []ch=new double[100010];
		ch[1]=1.0;
		for(int i=2;i<=100000;i++) {
			ch[i]=ch[i-1]/(double)i;
		}
		while(n<=100000) {
			double e=1;
			int k=1;
			for(int i=1;i<=n;i++) {
				e+=ch[i];
			}
			System.out.println(e);
			n+=10000;
		}
	}

}
